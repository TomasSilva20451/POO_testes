﻿using System;

namespace DLL3;

public static class Class1
{
    public static int sum(int x, int y)
    {
        return x + y;
    }
}

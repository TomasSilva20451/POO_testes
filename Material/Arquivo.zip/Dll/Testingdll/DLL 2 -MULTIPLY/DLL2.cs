﻿using System;
namespace DLL_2__MULTIPLY;

public static class DLL2
{
    public static int multiply(int x, int y)
    {
        return x * y;
    }
}


﻿namespace WhileLoop;

class Program
{
    static void Main(string[] args)
    {
        int index = 1;
        while (index <= 5) 
        {
            Console.WriteLine(index);
            index++; // incrementar 1;
        }



        Console.ReadLine();
    }
}

